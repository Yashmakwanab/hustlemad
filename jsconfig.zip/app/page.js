"use client"
import React, { useState } from 'react';

const Services = [
  {
    title: 'We Procure',
    description: 'We procure top-quality swags from trusted brands worldwide.',
    backgroundColor: '#F7DCFF',
    circleColor: '#F2C5FF',
    circleBorder: '#E58DFF',
    src: '/Images/landingPage/procureImage.png'
  },
  {
    title: 'We Customize',
    description: 'We customize to your exact needs; your brand, your design, your pride.',
    backgroundColor: '#C6F5FF',
    circleColor: '#B9FCFF',
    circleBorder: '#64C3FF',
    src: '/Images/landingPage/customizeImage.png'
  },
  {
    title: 'We Deliver',
    description: 'We store and deliver - your merchandise, your way.',
    backgroundColor: '#C7FFDE',
    circleColor: '#B1FFD2',
    circleBorder: '#46DB85',
    src: '/Images/landingPage/deliverImage.png'
  },
  {
    title: 'We Process',
    description: 'We process with care and precision, each item inspected and approved.',
    backgroundColor: '#FFE8BC',
    circleColor: '#FFDA92',
    circleBorder: '#E9933A',
    src: '/Images/landingPage/processImage.png'
  },
];

export default function Home() {
  const [value, setValue] = useState('Our Services');
  return (
    <main className={`transition duration-300 flex flex-col items-center justify-between ${value === "We Procure" ? "bg-[#F7DCFF]" : value === "We Customize" ? "bg-[#C6F5FF]" : value === "We Deliver" ? "bg-[#C7FFDE]" : value === "We Process" ? "bg-[#FFE8BC]" : "bg-[#FAFFC6]"} `}>
      <div className='w-full grid grid-cols-1 lg:grid-cols-2 container mt-14 relative'>
        <div className='w-full grid grid-cols-2'>
          {Services.map((Service, index) => (
            <div key={index} className={`transition duration-300 w-[140px] h-[140px] sm:w-[170px] sm:h-[170px] lg:w-[180px] lg:h-[180px] xl:w-[220px] xl:h-[220px] 2xl:w-[240px] 2xl:h-[240px] mb-[50px] flex flex-col place-content-center p-4 hover:p-3 bg-[${Service.circleColor}] rounded-full text-center hover:bg-[#FFF] hover:border-[6px] hover:border-[${Service.circleBorder}] cursor-pointer`} onMouseEnter={() => setValue(Service.title)}
              onMouseLeave={() => setValue("Our Services")}>
              <div className='text-[22px] font-[600] leading-[30px] text-[#0F143A] opacity-[72%]'>{Service.title}</div>
              <p className='text-[14px] font-[400] leading-[19px] text-[#0F143A] opacity-[72%]'>{Service.description}</p>
            </div>
          ))}
        </div>
        <div>
          {value === 'Our Services' ?
            <div className={`transition duration-300`}>
              <h2 className='text-[52px] font-[900] leading-[60px] text-[#0F143A] mb-6'>Our Services</h2>
              <p className='text-[28px] font-[400] leading-[38px] text-[#0F143A] opacity-[72%] mb-10'>We make the process of finding & acquiring the best Swags for your team easy.</p>
              <img src='/Images/landingPage/serviceImage.png' alt="our services" className='absolute bottom-0' />
            </div>
            :
            <>
              {Services.map((Service, index) => (
                <div key={index}>
                  {value === Service.title &&
                    <div className={`transition duration-300`}>
                      <h2 className='text-[52px] font-[900] leading-[60px] text-[#0F143A] mb-6'>{Service.title}</h2>
                      <p className='text-[28px] font-[400] leading-[38px] text-[#0F143A] opacity-[72%] mb-10'>{Service.description}</p>
                      <img src={Service.src} alt={Service.title} className='absolute bottom-0' />
                    </div>
                  }
                </div>
              ))}
            </>
          }
        </div>
      </div>
    </main>
  )
}
